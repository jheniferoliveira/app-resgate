package com.jhenifer.aplicativoresgate;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.graphics.Color;
import android.graphics.PorterDuff;
import android.graphics.drawable.ColorDrawable;
import android.os.Bundle;
import android.os.CountDownTimer;
import android.widget.ProgressBar;

public class Main2Activity extends AppCompatActivity {
    ProgressBar progressBar;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main2);
        getSupportActionBar().setBackgroundDrawable( new ColorDrawable( Color.parseColor("#b10000") ) );

        progressBar = findViewById(R.id.progressBar);
        progressBar.setMax(30);
        progressBar.setProgress(5);
        progressBar.getIndeterminateDrawable().setColorFilter(0xFFFF0000, PorterDuff.Mode.MULTIPLY);

        new CountDownTimer( 6000, 1000) {
            public void onTick(long millisUntilFinished) {
            }

            @Override
            public void onFinish() {
                Intent activity = new Intent(getApplicationContext(), Login.class);
                startActivity(activity);

            }
        }.start();
    }
}
