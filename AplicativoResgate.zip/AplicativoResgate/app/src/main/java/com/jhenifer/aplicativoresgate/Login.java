package com.jhenifer.aplicativoresgate;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.graphics.Color;
import android.graphics.PorterDuff;
import android.graphics.drawable.ColorDrawable;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;

public class Login extends AppCompatActivity {
    TextView textViewEsqueci, textViewCadastro;
    EditText editTextLogin, editTextSenha;
    Button buttonEntrar;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_login);
        getSupportActionBar().setBackgroundDrawable( new ColorDrawable( Color.parseColor("#b10000") ) );

        editTextLogin = findViewById(R.id.editTextLogin);
        editTextSenha = findViewById(R.id.editTextSenha);
        textViewEsqueci = findViewById(R.id.textViewEsqueci);
        textViewCadastro = findViewById(R.id.textViewCadastro);
        buttonEntrar = findViewById(R.id.buttonEntrar);
    }

    public void esqueciSenha(View view){
        Intent esqueci = new Intent(getApplicationContext(),EsqueciSenha.class);
        startActivity(esqueci);
    }
    public  void cadastro(View view){
        Intent cadastro = new Intent(getApplicationContext(),MainActivity.class);
        startActivity(cadastro);
    }
}
