package com.jhenifer.aplicativoresgate;

import androidx.appcompat.app.AppCompatActivity;

import android.graphics.Color;
import android.graphics.drawable.ColorDrawable;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.RadioButton;
import android.widget.Toast;

public class MainActivity extends AppCompatActivity {
    EditText editTextNome, editTextEndereco, editTextNumero, editTextBairro, editTextCidade, editTextEstado,
            editTextTelefone, editTextEmail;
    RadioButton radioButtonComum, radioButtonAdmin;
    Button buttonSalvar;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.main_activity);
        getSupportActionBar().setBackgroundDrawable( new ColorDrawable( Color.parseColor("#b10000") ) );

        editTextNome = findViewById(R.id.editTextNome);
        editTextEndereco = findViewById(R.id.editTextEndereco);
        editTextNumero = findViewById(R.id.editTextNumero);
        editTextBairro = findViewById(R.id.editTextBairro);
        editTextCidade = findViewById(R.id.editTextCidade);
        editTextEstado = findViewById(R.id.editTextEstado);
        editTextTelefone = findViewById(R.id.editTextTelefone);
        editTextEmail = findViewById(R.id.editTextEmail);
        radioButtonComum = findViewById(R.id.radioButtonComum);
        radioButtonAdmin = findViewById(R.id.radioButtonAdmin);
        buttonSalvar = findViewById(R.id.buttonSalvar);

        //código que captura o clique do botão
        buttonSalvar.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if (validarCampos()) {
                    Toast.makeText(getApplicationContext(),
                            "cadastrado com sucesso",
                            Toast.LENGTH_SHORT).show();
                }
            }
        });
    }

    public boolean validarCampos() {
        boolean resposta = true;

        if (editTextNome.getText().toString().isEmpty()) {
            Toast.makeText(getApplicationContext(),
                    "preencha este campo!!",
                    Toast.LENGTH_LONG).show();
            editTextNome.requestFocus();
            resposta = false;
        } else if (editTextEndereco.getText().toString().isEmpty()) {
            Toast.makeText(
                    getApplicationContext(),
                    "preencha o campo Endereço",
                    Toast.LENGTH_LONG).show();
            editTextEndereco.requestFocus();
            resposta = false;
        } else if (editTextNumero.getText().toString().isEmpty()) {
            Toast.makeText(
                    getApplicationContext(),
                    "preencha o campo N°",
                    Toast.LENGTH_LONG).show();
            editTextNumero.requestFocus();
            resposta = false;
        } else if (editTextBairro.getText().toString().isEmpty()) {
            Toast.makeText(
                    getApplicationContext(),
                    "preencha o campo Bairro",
                    Toast.LENGTH_LONG).show();
            editTextBairro.requestFocus();
            resposta = false;
        } else if (editTextCidade.getText().toString().isEmpty()) {
            Toast.makeText(
                    getApplicationContext(),
                    "preencha o campo cidade",
                    Toast.LENGTH_LONG).show();
            editTextCidade.requestFocus();
            resposta = false;
        } else if (editTextEstado.getText().toString().isEmpty()) {
            Toast.makeText(
                    getApplicationContext(),
                    "preencha o campo estado",
                    Toast.LENGTH_LONG).show();
            editTextEstado.requestFocus();
            resposta = false;
        } else if (editTextTelefone.getText().toString().isEmpty()) {
            Toast.makeText(
                    getApplicationContext(),
                    "preencha o campo telefone",
                    Toast.LENGTH_LONG).show();
            editTextTelefone.requestFocus();
            resposta = false;
        } else if (editTextEmail.getText().toString().isEmpty()) {
            Toast.makeText(
                    getApplicationContext(),
                    "preencha o campo E-mail",
                    Toast.LENGTH_LONG).show();
            editTextEmail.requestFocus();
            resposta = false;
        } else if (!radioButtonComum.isChecked() && !radioButtonAdmin.isChecked()) {
            Toast.makeText(
                    getApplicationContext(),
                    "Selecione uma opção",
                    Toast.LENGTH_LONG).show();

            resposta = false;
        }

        return resposta;
    }

}
